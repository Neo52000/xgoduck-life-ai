# Publier XGO-Duck Life AI V3.3 sur GitHub

Compte GitHub identifié : `Neo52000`. Nom proposé : **`xgoduck-life-ai`**.

## Étape 1 — Créer le dépôt privé

Ouvrir <https://github.com/new> puis choisir :

- **Owner** : `Neo52000`
- **Repository name** : `xgoduck-life-ai`
- **Visibility** : **Private**
- **Description** : `XGO-Duck Life AI - cerveau cognitif, mémoire persistante et auto-amélioration supervisée (sans moteurs)`
- **Ne cocher aucune initialisation** (pas de README, pas de .gitignore, pas de licence), car le projet local contient déjà ces fichiers et un commit initial.

Cliquer sur **Create repository**.

## Étape 2 — Publier le code

Extraire l'archive `xgoduck_life_ai_github_ready.zip`. Elle contient un dépôt Git initialisé sur `main`, avec un commit initial. Dans le dossier extrait :

```bash
git remote add origin https://github.com/Neo52000/xgoduck-life-ai.git
git push -u origin main
```

Une connexion GitHub (Git Credential Manager, GitHub CLI ou méthode équivalente) peut être demandée. **Ne jamais coller de jeton d'accès dans un chat ou un fichier versionné.**

À défaut, il suffit de créer le dépôt privé puis de prévenir ChatGPT : l'application GitHub connectée peut importer les fichiers dans un dépôt existant, mais elle ne peut pas créer elle-même de nouveaux dépôts.

## Étape 3 — Contrôles après import

- Vérifier que GitHub affiche **Private** et la branche `main`.
- Vérifier les fichiers `README.md`, `lifeai/`, `tests/`, `tools/`, `compose.yml`, `compose.prod.yml`, `.github/workflows/ci.yml`.
- Ouvrir l'onglet **Actions** et s'assurer que le workflow **Life AI tests** réussit.
- Éviter de rendre le dépôt public avant vérification des dépendances et des droits de redistribution.

## Exclusions de sécurité

Ne jamais versionner `.env`, les clés API, les mots de passe, la base de souvenirs, les photographies utilisateurs, les sauvegardes ou les fichiers de sortie de candidats de code. Ces chemins sont exclus dans `.gitignore`.

## État du projet

La V3.3 reste un **prototype**. Le dépôt GitHub n'est pas un déploiement VPS, aucun code de génération ne s'exécute automatiquement en production et aucun contrôle moteur n'est présent.
